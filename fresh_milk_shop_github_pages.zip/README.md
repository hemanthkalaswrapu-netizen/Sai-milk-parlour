# FRESH+ MILK — GitHub Pages website

1. Open `index.html` and change FRESH+ MILK to your real shop name.
2. Find `WHATSAPP_NUMBER` near the bottom and replace `91XXXXXXXXXX` with your WhatsApp number including country code, without +, spaces or dashes. India example: `919876543210`.
3. Replace sample products, prices, photos, shop address and opening hours.
4. Upload `index.html` to the root of your GitHub repository and commit.
5. Open Settings → Pages → Deploy from a branch → `main` → `/(root)` → Save.

Your published URL will look like `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

This website opens WhatsApp for orders; it does not process payments or store orders. Sample product details must be replaced before publishing.
